#include <stdio.h>
#include <stdlib.h>
/*The goal of this program is to use bitwise functions in order to get certaindexes in the binary representation of numbers and also manipulate those binary values*/
void get(unsigned short num,int count){
	/*this gets the ith bit based on a file input*/
	unsigned short number;
	number = (num>>count)&1;
	printf("%hu\n",number);
}
unsigned short comp(unsigned short  num, int count){
       /*this gets the value at the nth bit and transforms it to its complement*/
	unsigned short mask=1;
	mask = mask<<count;
	num = (num^mask);
	return num;
}
unsigned short set(unsigned short num, int count, int newval){
	/*this changes the nth bit to either a 1 or 0 depending on what the user input is*/
	unsigned short mask =1;
	if(newval==0){
		return(num&~(mask<<count));
	}
	if(newval==1){
		return(num|(mask<<count));
	}
	return num;
}
		
int main(int argc, char** argv){
	FILE *f = fopen(argv[1],"r");
	int n,type;
	char firstlet[5];
	if(f==NULL){
		exit(0);
	}
	unsigned short actual;
	fscanf(f,"%hu",&actual);
	while(fscanf(f,"%s",firstlet)==1){
		fscanf(f,"%d %d",&n,&type);
		if(firstlet[0]=='g'){
			get(actual,n);
		}
		else if(firstlet[0]=='c'){
			actual = comp(actual,n);
			printf("%hu\n",actual);
		}
		else if(firstlet[0]=='s'){
			actual = set(actual,n,type);
			printf("%hu\n",actual);
		}
	}
	fclose(f);

}

