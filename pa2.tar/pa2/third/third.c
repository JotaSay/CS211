#include <stdlib.h>
#include <stdio.h>

int main(int argc, char**argv){
	if(argc<1)
		exit(0);
	unsigned short number = strtoul(argv[1],NULL,10);
	int i = 0;
	for(i=0;i<8;i++){
		if((number>>i&1)!=((number>>(15-i)&1))){
				printf("Not-Palindrome\n");
				return 0;
		}
	}
	printf("Is-Palindrome\n");
	return 0;
}


