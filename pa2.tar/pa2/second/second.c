#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv){
	if(argc <1){
		exit(0);
	}
	unsigned short yeet =  strtoul(argv[1],NULL,10);
	int i,pairs=0,count=0,total=0;
	unsigned short parity=0;
	for(i=0;i<16;i++){
		parity= yeet & 1;
		if(parity == 1){
			count++;
			total++;
			if(count == 2){
				pairs++;
				count=0;
			}
		}else
			count=0;		
		yeet = yeet>>1;
	}
	if(total%2==0){
		printf("Even-Parity	%d\n",pairs);
	}
	else
		printf("Odd-Parity	%d\n",pairs);
	return 0;
}
