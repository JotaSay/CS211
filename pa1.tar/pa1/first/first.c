#include <stdio.h>
#include <stdlib.h>
void sort(int *arr,int first,int total){
	int i,counter,inside,temp,temp2;
	/*This sorts the first half ascending(even)*/
	for (i=1;i<first;i++){
		inside = i;
		counter = i-1;
		while(counter>=0){
			if(arr[counter]>arr[inside]){
				temp = arr[counter];
				arr[counter] = arr[inside];
				arr[inside] = temp;
				counter--;
				inside--;
			}else{
				break;
			}
		}
	}
	/*this sorts the second half in descending order (odd)*/
	for(temp = first+1;temp<total;temp++){
		inside= temp;
		counter = temp-1;
		while(counter>=first){
			if(arr[counter]<arr[inside]){
				temp2 = arr[counter];
				arr[counter] = arr[inside];
				arr[inside]= temp2;
				counter--;
				inside--;
			}else{
				break;
			}
		}
	}
}
int main(int argv,char** argc){
	int info,i,digit,noti;
	FILE*f=fopen(argc[1],"r");
	if(f==NULL){
		printf("File not read\n");
		exit(0);
	}
	fscanf(f,"%d",&info);
	int array[info];
	int evenedout[info];
	/*scans in the values given the size which is (info)*/
	for( i=0;i<info;i++){
		fscanf(f,"%d",&digit);
		array[i] = digit;
	}
	noti= info-1;
	digit = 0;
	/*here we're just putting the evens on the left side and odds on the right"*/
	for(i=0;i<info;i++){
		if(array[i]%2==0){
			evenedout[digit]= array[i];
			digit++;
		}else{
			evenedout[noti] = array[i];
			noti--;
		}
	}
	sort(evenedout,digit,info);
	for(i=0;i<info;i++){
		printf("%d	",evenedout[i]);
	}
	fclose(f);
	return 0;
}
