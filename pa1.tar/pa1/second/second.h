typedef struct node{
	int data;
	struct node* next;
}node;
