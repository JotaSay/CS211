#include <stdio.h>
#include <stdlib.h>
#include "second.h"
void crear(node **head,int data){
	node* current =* head;
	node * prev = NULL;
	/* case 0 our LL is empty*/
	if(*head==NULL){
		node* new = (node*)malloc(sizeof(node));
		new->data = data;
		new->next = NULL;
		*head = new;
		return;
	}
	/*case 1, if what we are inserting is the smallest data type aka it goes before the head*/
	if(data<=current->data){
		/*create node at beginning*/
		node *new = (node*)malloc(sizeof(node));
		new->data = data;
		new->next = current;
		*head = new;
		return;
	}
	/*case 2, we are inserting somewhere in the middle of the linked list*/
	while(current!=NULL){
		/* data is larger than the current so we must move over*/
		if(data>current->data){
			prev = current;
			current = current->next;
			/* case 3 we reached the end of our LL and add to the end*/
			if(current==NULL){
				node*new =(node*)malloc(sizeof(node));
				new->data= data;
				new->next = NULL;
				prev->next = new;
				return;
			}
		}
		else{
			/*insert the node before your current*/
			node *new = (node*)malloc(sizeof(node));
			new->data = data;
			new->next = current;
			prev->next = new;
			return;
		}
	}

}
void borrar(node**head,int data){
	node* current =* head;
	node* prev = NULL;
	/*case 0, the LL is empty*/
	if(current==NULL){
		return;
	}
	/*case 1, the target is the head*/
	if(current->data==data){
		if(current->next==NULL){
			*head = NULL;
			free(current);
			return;
		}
		*head = current->next;
		free(current);
		return;
	}
	/*case 2, the target is somewhere in the middle of the LL should also include the end*/
	while(current!=NULL){
		if(current->data == data){
			/*delete the current node and relink the others */
			if(current->next==NULL){
				prev->next = NULL;
				free(current);
				return;
			}
			prev->next = current->next;
			free(current);
			return;
		}else{
			prev = current;
			current = current->next;
		}
	}
}


int main(int argc, char** argv){
	/* open the file and then begin to pull i or d will return error if file not found and shoud
	 * return 0 if the file contains no data*/
	char instruction;
	int info,count;
	FILE*f = fopen(argv[1],"r");
	node* head= NULL;
	count = 0;
	if(f==NULL){
		printf("error");
		exit(0);
	}
	/*checking if the file only contains white space*/

	while(fscanf(f,"%c %d \n",&instruction,&info)!=EOF){
		if(instruction =='i'){
			/*tries to create a new node in the sorted location*/
			crear(&head,info);
		}else if(instruction =='d'){
			/*tries to find the node that contains the data*/
			borrar(&head,info);
		}
	}
	node* curr= head;
	while(curr!=NULL){
		count++;
		curr= curr->next;
	}
	curr = head;
	node* prev = NULL;
	printf("%d\n",count);
	if(curr==NULL){
		printf("\n");
	}
	while(curr!=NULL){
		if(prev==NULL||curr->data!=prev->data){
			if(curr->next==NULL){
				printf("%d",curr->data);
			}else
				printf("%d	",curr->data);
		}
			prev = curr;
			curr = curr->next;
	}
	curr = head;
	prev = NULL;
	while(curr!=NULL){
		prev = curr;
		curr= curr->next;
		free(prev);
	}

	fclose(f);
	return 0;
}

