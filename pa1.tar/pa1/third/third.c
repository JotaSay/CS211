#include <stdlib.h>
#include <stdio.h>
#include "third.h"
void crear(int hashval,int data,linked** hash,int *collisions){
	/*case-1, trying to go past our array size*/
	if(hashval >9999){
		return;
	}
	if(hash[hashval]==NULL){
		/* case 0, the key is empty and create a node for that key*/
		linked* new = (linked*)malloc(sizeof(linked));
		new->data = data;
		new->next = NULL;
		hash[hashval] = new;
	}else{
	/*case 2, there is already another value in this key*/
		/*case 3, make sure the value isnt repeating*/
		linked* current = hash[hashval];
		while(current!=NULL){
			if(current->data == data){
				*collisions= *collisions+1;
				return;
			}
			current= current->next;
		}
		/*case 4, the value is not a duplicate*/
		linked* new = (linked*)malloc(sizeof(linked));
		new->data = data;
		new->next = hash[hashval];
		hash[hashval] = new;
		*collisions = *collisions+1;
	}
}
void search(int hashval, int data, linked**hash, int*success){
	/*case 0, we are looking at an empty hash*/
	linked* current = hash[hashval];
	if(current==NULL){
		return;
	}
	/*case 1, we are looking at a hash that has 1 or more values and must go through the linked list to see if we
	 * can find the final value*/
	while(current!=NULL){
		if(current->data==data){
			*success= *success +1;
			return;
		}
		current = current->next;
	}

}
int main(int argc, char**argv){
	/*take file input and then begin either hasing or searching*/
	int collisions =0;
	int searches = 0;
	char info;
	int data;
	FILE* f = fopen(argv[1],"r");
	if(f==NULL){
		printf("File not read \n");
		exit(0);
	}
	linked* hashtable[10000] = {NULL};
	while(fscanf(f,"%c",&info) ==1){
		fscanf(f,"%d",&data);
		int hashval = data%10000;
		if(hashval<0){
			hashval=hashval+10000;
		}
		if(info=='i'){
			crear(hashval,data,hashtable,&collisions);
		}
		if(info=='s'){
			search(hashval,data,hashtable,&searches);
		}
	}
	printf("%d\n",collisions);
	printf("%d\n",searches);
	/*free all of the malloc now*/
	linked * current = NULL;
	linked *prev = NULL;
	for(data=0;data<10000;data++){
		if(hashtable[data]==NULL){
			continue;
		}else{
			current = hashtable[data];
			while(current!=NULL){
				prev = current;
				current = current->next;
				free(prev);
			}
		}

	}
	fclose(f);

}
