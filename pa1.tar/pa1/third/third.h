typedef struct linked{
	int data;
	struct linked* next;
}linked;
