#include <stdio.h>
#include <stdlib.h>
#include "sixth.h"
/* goals,
 * inserting, case 0 if its empty create node and make head
 * if not then check if its greater or less than, skip if they are the same
 * call this function recursivley until u get to the null*/
node* insert(node *root,int data){
	/*case 0, empty bst*/
	if(root==NULL){
		node* nuevo = (node *)malloc(sizeof(node));
		nuevo->data= data;
		nuevo->left = nuevo->right = NULL;
		return nuevo;
	}
	/*case 1, it isnt empty and we must check its > or < than*/
	if(root->data >data){
		/*go left*/
		root->left = insert(root->left,data);
	}
	if(root->data<data){
		/*go right*/
		root->right = insert(root->right,data);
	 }
	/*last case it is equal to the data so do nothin */
	return root;	
}
void inorder(node*root){
	if(root==NULL){
		return;
	}
	/*go to left child first*/
	inorder(root->left);
	/*print what should be the root of curent position*/
	printf("%d	",root->data);
	/*go to right child last*/
	inorder(root->right);
}
void clearingup(node*root){
	if(root==NULL){
		return;
	}
	clearingup(root->right);
	clearingup(root->left);
	free(root);
}
		

int main(int argv, char** argc){
	FILE*f= fopen(argc[1],"r");
	if(f==NULL){
		printf("error");
		exit(0);
	}
	char info;
	int data;
	node * head = NULL;
	while(fscanf(f,"%c",&info)==1){
		if(info=='i'){
			fscanf(f,"%d",&data);
			head =insert(head,data);
		}
	}

	inorder(head);
	clearingup(head);
	fclose(f);
	return 0;
}
