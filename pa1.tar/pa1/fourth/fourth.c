#include <stdio.h>
#include <stdlib.h>

int main(int argv, char**argc){
	/*first we are going to take the input and create the array*/
	int i,array1r,j,array1c,array2r,array2c,digit,iterate;
	FILE* f = fopen(argc[1],"r");
	fscanf(f,"%d",&array1r);
	fscanf(f,"%d",&array1c);
	int ** parray1 = (int **)(malloc(sizeof(int*) *array1r));
	/*take in the first matrix*/
	for(i=0; i<array1r;i++){
		parray1[i]=(int*)(malloc(sizeof(int)*array1c));
	}
	for(i=0;i<array1r;i++){
		for(j=0;j<array1c;j++){
			fscanf(f,"%d",&digit);
			parray1[i][j] = digit;
		}
	}
	fscanf(f,"%d",&array2r);
	fscanf(f,"%d",&array2c);

	int **parray2=(int**)(malloc(sizeof(int*)*array2r));
	/*take in the second matrix*/
	for(i=0;i<array2r;i++){
		parray2[i]=(int*)(malloc(sizeof(int)*array2c));
	}
	for(i=0;i<array2r;i++){
		for(j=0;j<array2c;j++){
			fscanf(f,"%d",&digit);
			parray2[i][j]= digit;
		}
	}
	int ** parray3 =(int**)(malloc(sizeof(int*)*array1r));
	for(i=0;i<array1r;i++){
		parray3[i]=(int*)(malloc(sizeof(int)*array2c));
	}
	digit=0;
	if(array1c==array2r){
		/*if the matrices are of the same collumn n row respectively for 1 and 2 then multiply them*/
		for(i=0;i<array1r;i++){
			for(j=0;j<array2c;j++){
				for(iterate=0;iterate<array1c;iterate++){
					digit+= parray1[i][iterate]*parray2[iterate][j];	
				}
				parray3[i][j]= digit;
				digit=0;
			}
		}
	}else{
		printf("bad-matrices");
		exit(0);
	}
	for(i=0;i<array1r;i++){
		for(j=0;j<array2c;j++){
			printf("%d",parray3[i][j]);
			if(j<array2c){
				printf("	");
			}
		}
		if(i<array1r){
			printf("\n");
		}
	}
	/*free's everybody*/
	for(i=0;i<array1r;i++){
		free(parray1[i]);
	}
	free(parray1);
	for(i=0;i<array2r;i++){
		free(parray2[i]);
	}
	free(parray2);
	for(i=0;i<array1r;i++){
		free(parray3[i]);
	}
	free(parray3);
	fclose(f);
	return 0;
}


