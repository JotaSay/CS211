#include <stdlib.h>
#include <stdio.h>

int main(int argc, char** argv){
	int meep,yeet;
	char c;
	for(meep=1;meep<argc;meep++){
		while(argv[meep][yeet]!='\0'){
			c = argv[meep][yeet];
			if(c=='a'||c=='A'||c=='i'||c=='I'||c=='e'||c=='E'||c=='O'||c=='o'||c=='u'||c=='U'){
				printf("%c",argv[meep][yeet]);
			}
			yeet++;
		}
		yeet=0;
	}

}	
		
